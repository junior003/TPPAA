#include "Cabecalho.h"
#include "mergesort.cpp"
//funcoes referentes a lista encadeada
void insere_Lista(Caixa x, Celula *cl)
{
	Celula *nova;
	nova =(Celula*) malloc(sizeof(Celula));
	nova->cx = x;
	nova->prox = cl->prox;
	cl->prox = nova;
}
void print_Lista(Celula *cl) {
	Celula *p;
	printf("Valor das caixas empilhadas:\n");
	for (p = cl->prox; p!=NULL; p = p->prox)
	{
		printf("ID: %d A:%d L:%d P:%d V:%d R:%d \n", p->cx.id,p->cx.altu, p->cx.larg, p->cx.prof, p->cx.valor,p->cx.rot);
	}
}

void Cria_Lista(Lista &P)
{
	P.c = (Celula*)malloc(sizeof(Celula));
	P.c->prox = NULL;
}

//funcao referente a leitura de dados
void Leitura()
{
	//printf("oooi");

	int i;
	int altu_aux=0;
	int larg_aux=0;
	int prof_aux=0;
	scanf("%d", &N);
	scanf("%d", &H);
	caixas = (Caixa *)malloc((2 * N) * sizeof(Caixa));
	for (i = 0; i < 2*N; i++)
	{
		scanf("%d",&caixas[i].valor);
		caixas[i + 1].valor = caixas[i].valor;
		i++;
	}
	for (i = 0; i < 2*N; i++)
	{
		scanf("%d", &larg_aux);
		scanf("%d", &altu_aux);
		scanf("%d", &prof_aux);

		caixas[i].id = i;
		caixas[i].rot = 1;
		caixas[i].altu = altu_aux;
		caixas[i].larg = larg_aux;
		caixas[i].prof = prof_aux;

		caixas[i + 1].id = i;
		caixas[i+1].rot = 2;
		caixas[i+1].altu = larg_aux;
		caixas[i+1].larg = altu_aux;
		caixas[i+1].prof = prof_aux;
		i++;
		
	}
	M_caixas_dup = (int **)malloc(((2*N) + 1) * sizeof(int*));
	M_din = (Caixa **)malloc(((2*N)+1) * sizeof(Caixa*));
	for (i = 0; i < (2*N)+1; i++)
	{
		M_caixas_dup[i] = (int*)malloc((H + 1) * sizeof(int));
		M_din[i] = (Caixa*)malloc((H+1) * sizeof(Caixa));
	}
	//printf("oooi 2");
}


int buscaMax(int coluna,int ultima_linha)
{
	int max;
	int indice=0;

	max = M_din[0][coluna].valor;
	for (int i = 0; i < ultima_linha; i++)
	{
		if (M_din[i][coluna].valor >= max)
		{
			indice = i;
			max = M_din[i][coluna].valor;
		}
	}
	return indice;
}
int Empilha()
{
	Lista P;
	Cria_Lista(P);
	//printf("oooi 3");
	mergeSort(caixas, 0, 2*N);
	//printf("oooi 4");
	int i, j,k;
	int linha_max = 0,resto=0;
	Caixa valor1, valor2;
	for (i = 0; i < (2*N)+1; i++)
	{
		M_din[i][0].valor = 0;
		M_din[i][0].altu = -1;
		M_din[i][0].prof = -1;
		M_din[i][0].larg = -1;
		M_caixas_dup[i][0]= 0;
	}
	for (j = 0; j < H+1; j++)
	{
		M_din[0][j].valor = 0;
		M_din[0][j].altu = -1;
		M_din[0][j].prof = -1;
		M_din[0][j].larg = -1;
		M_caixas_dup[0][j] = 0;
	}

	for (i = 1; i < (2*N)+1; i++)
	{
		for (j = 1; j < H+1; j++)
		{
			M_caixas_dup[i][j] = 0;
			M_din[i][j].valor = 0;
			valor1 = M_din[i - 1][j];
			if (caixas[i-1].altu <=j)
			{

				//teste
				resto = j - caixas[i - 1].altu;
				printf("R: %d,i: %d, j:%d, h:%d \n", resto,i,j, caixas[i - 1].altu);
				while ((resto >= caixas[i - 1].altu)&& (resto*caixas[i - 1].altu <=H))
				{
					printf("%d+", caixas[i - 1].valor);
					M_caixas_dup[i][j]++;
					M_din[i][j].valor += caixas[i - 1].valor;
					resto -= caixas[i - 1].altu;
				}
				if (resto < 0)
				{
					resto += caixas[i - 1].altu;
				}
				//
				linha_max = buscaMax(resto, i);
				valor2.valor = M_din[linha_max][j - caixas[i-1].altu].valor;
				valor2.larg = M_din[linha_max][j - caixas[i - 1].altu].larg;
				valor2.prof = M_din[linha_max][j - caixas[i - 1].altu].prof;
				
				if (valor2.valor != 0)
				{
					
					if ((valor2.larg >= caixas[i-1].larg) && (valor2.prof >= caixas[i-1].prof))
					{
						
						valor2.valor += caixas[i-1].valor;
						valor2.altu = caixas[i-1].altu;
						valor2.larg = caixas[i-1].larg;
						valor2.prof = caixas[i-1].prof;
					}
					else
					{
						valor2.valor = caixas[i - 1].valor;
						valor2.altu = caixas[i - 1].altu;
						valor2.larg = caixas[i - 1].larg;
						valor2.prof = caixas[i - 1].prof;
					}
				}
				else
				{
					valor2 = caixas[i-1];
				}
				
			}
			else
			{
				valor2.valor = 0;
			}
			if (valor2.valor ==0)
			{
				printf(".%d.+", valor1.valor);
				M_din[i][j].valor += valor1.valor; // se nao couber
				M_din[i][j].altu = valor1.altu;
				M_din[i][j].larg = valor1.larg;
				M_din[i][j].prof = valor1.prof;
			}
			else
			{
				printf("%d+", valor2.valor);
				M_din[i][j].valor += valor2.valor; // se couber
				M_din[i][j].altu = valor2.altu;
				M_din[i][j].larg = valor2.larg;
				M_din[i][j].prof = valor2.prof;
			}
		}
		printf("\n");
	}

	i = buscaMax(H, (2*N) + 1); ;
	j = H;
	
	//itens empilhados
	
	printf("posicoes das caixas resgatadas: \n");
	while (j >= 0)
	{
		if (i < 1)
		{
			break;
		}
		if ((M_din[i][j].valor != M_din[i - 1][j].valor ))
		{
			if (M_caixas_dup[i][j] == 0)
			{
				printf("N - valor da pos: %d - caixa do topo da pos:%d", M_din[i][j].valor, caixas[i - 1].valor);
				insere_Lista(caixas[i - 1], P.c);
			}
			else
			{
				for (k = 0; k < M_caixas_dup[i][j]+1; k++)
				{
					insere_Lista(caixas[i - 1], P.c);
				}
				printf("S:%d- valor da pos: %d - caixa do topo da pos:%d", M_caixas_dup[i][j], M_din[i][j].valor, caixas[i - 1].valor);

			}
			j= j - caixas[i - 1].altu*(M_caixas_dup[i][j] + 1);
			printf(" | vai para a coluna:%d", j);
			i= buscaMax(j,i);
			printf(" linha:%d \n", i);
		}
		else
		{
			i--;
		}
	}
	
	
	printf("\n");
	printf("\n");
	for (i = 0; i < (2*N)+1; i++)
	{
		for (j = 0; j < H+1; j++)
		{
			printf("%d ", M_din[i][j].valor);
		}
		printf("\n");
	}
	

	print_Lista(P.c);
	int resultado = buscaMax(H, (2*N)+1);
	printf("ta na linha %d ", resultado);
	return M_din[resultado][H].valor;

}