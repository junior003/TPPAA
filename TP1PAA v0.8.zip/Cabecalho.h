#ifndef CABECALHO_H
#define CABECALHO_H

#include <stdio.h>
#include <stdlib.h>

using namespace std;

typedef struct box
{
	int id;
	int rot; //rotacao 1 ou 2
	int altu; 
	int larg; 
	int prof; 
	int valor;
}Caixa;

typedef struct cel {
	Caixa cx;
	struct cel *prox;
}Celula;

typedef struct lista
{
	Celula *c;
}Lista;

int **M_caixas_dup;
Caixa **M_din; //matriz que utiliza prog dinamica
Caixa *caixas; // vetor de caixas existentes
int H; //altura maxima da pilha 
int N; // numero de caixas

void Leitura();
int Empilha();
void mergeSort(Caixa vetor[], int comeco, int fim);
void merge(Caixa vetor[], int comeco, int meio, int fim);
#endif // !CABECALHO_H