#include "Cabecalho.h"
#include "Funcoes.cpp"
using namespace std; 

int main()
{
	scanf("%d", &N);
	scanf("%d", &H);
	caixas = (Caixa *)malloc((2*N) * sizeof(Caixa));
	Leitura();
	int lucro_obt;
	lucro_obt = Empilha();
	printf("Lucro maximo obtido: %d", lucro_obt);
	return 0;
}


